"""Component IR 1.0: validated data, canonical serialization, and hashing."""

from partsmith.ir.canonical import canonical_json
from partsmith.ir.errors import IRValidationError, Issue
from partsmith.ir.model import (
    ComponentIR,
    canonical_ir,
    ir_hash,
    normalize_ir,
    validate_ir,
)
from partsmith.ir.schema import load_schema
from partsmith.ir.units import normalize_quantity

__all__ = [
    "ComponentIR",
    "IRValidationError",
    "Issue",
    "canonical_ir",
    "canonical_json",
    "ir_hash",
    "load_schema",
    "normalize_ir",
    "normalize_quantity",
    "validate_ir",
]
