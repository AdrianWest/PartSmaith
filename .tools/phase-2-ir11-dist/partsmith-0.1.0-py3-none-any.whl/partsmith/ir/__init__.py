"""Component IR 1.0/1.1: versioned validation, migration, and hashing."""

from partsmith.ir.canonical import canonical_json
from partsmith.ir.errors import IRValidationError, Issue
from partsmith.ir.migration import MigrationResult, migrate_v1_0_to_v1_1
from partsmith.ir.model import (
    ComponentIR,
    canonical_ir,
    ir_hash,
    normalize_ir,
    validate_ir,
)
from partsmith.ir.revised import RequirementsContext
from partsmith.ir.schema import SUPPORTED_VERSIONS, load_schema
from partsmith.ir.units import normalize_quantity

__all__ = [
    "ComponentIR",
    "IRValidationError",
    "Issue",
    "MigrationResult",
    "RequirementsContext",
    "SUPPORTED_VERSIONS",
    "canonical_ir",
    "canonical_json",
    "ir_hash",
    "load_schema",
    "migrate_v1_0_to_v1_1",
    "normalize_ir",
    "normalize_quantity",
    "validate_ir",
]
